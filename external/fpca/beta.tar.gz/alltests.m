clear
diffsnormtest

clear
diffsnormtests

clear
diffsnormctest

clear
diffsnormctests

clear
diffsnormstest

clear
diffsnormstests

fprintf('\n\n')
clear
eigenntest

fprintf('\n\n')
clear
eigenntests

fprintf('\n\n')
clear
eigenstest

fprintf('\n\n')
clear
eigenstests

fprintf('\n\n')
clear
pcatest

fprintf('\n\n')
clear
pcatests
