Running alltests.m validates all six main functions (diffsnorm, diffsnormc,
diffsnorms, pca, eigens, and eigenn) for both dense and sparse matrices. Each
main function comes with two testing scripts, one for dense matrices and one
for sparse. Most users will probably want to begin with pca.m.
